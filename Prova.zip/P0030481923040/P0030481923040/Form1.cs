﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481923040
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lstBxResultado.Items.Clear();
            double[,] vendas = new double[10, 4];
            double totalGeral = 0;
            int mes, semana, i, j;
            bool test = true;
            string aux = "";
            mes = vendas.GetLength(0);
            semana = vendas.GetLength(1);

            totalGeral = 0;
            for (i = 0; i < mes; i++)

            {
                double totalMes = 0;

                for (j = 0; j < semana; j++)
                {
                    do
                    {
                        aux = (Interaction.InputBox("Digite o valor da semana " +
                            (j + 1) + " do mês " + (i + 1), "Entrada dos valores"));

                        if (!double.TryParse(aux, out vendas[i, j]))
                        {
                            MessageBox.Show("Dados de entrada inválidos, digite novamente");
                            aux = "";
                            test = true;
                        }
                        else if (aux == "")
                        {
                            MessageBox.Show("Digite um valor!");
                            test = true;
                        }
                        else
                        {
                            lstBxResultado.Items.Add("Total do Mês: " + (i + 1) +
                                " Semana: " + (j + 1) +
                                " R$" + vendas[i, j].ToString("N2"));
                            totalMes += vendas[i, j];
                            test = false;
                        }

                    } while (test);

                }

                lstBxResultado.Items.Add(">>Total Mês: " + "R$" + totalMes.ToString("N2")+"\n\n\n\n");
                lstBxResultado.Items.Add("..........................." + "\n\n\n");
                totalGeral += totalMes;
            }

            lstBxResultado.Items.Add(">> Total Geral:" + " R$" + totalGeral.ToString("N2"));
        }

    }
}
